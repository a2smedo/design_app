


<?php $__env->startSection('head'); ?>
  Designs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="col py-2">

    <div class="row">
      <div class="col">
        <?php if(session('msgAdd')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('msgAdd')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgUpdate')): ?>
          <div class="alert alert-info" role="alert">
            <?php echo e(session('msgUpdate')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgDeleted')): ?>
          <div class="alert alert-warning" role="alert">
            <?php echo e(session('msgDeleted')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgNoDeleted')): ?>
          <div class="alert alert-danger" role="alert">
            <?php echo e(session('msgNoDeleted')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>



    <div class="row">
      <div class="col">

        <div class="card">
          <div class="card-header">
            <h3 class="card-title"> All Desgins </h3>

            <div class="card-tools">
              <div class="card-tools">
                <a href="<?php echo e(url('/dashboard/designs/create')); ?>" class="btn btn-primary btn-sm" title="Add new Design">Add new</a>
              </div>
            </div>
          </div>
        </div>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover text-nowrap">
            <thead>
              <tr>
                <th>ID</th>
                <th>Category</th>
                <th>Name (en) </th>
                <th>Slider</th>
                <th>Main Image</th>
                <th>Price</th>
                <th>Active</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $design): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <td> <?php echo e($loop->iteration); ?> </td>

                  <td> <?php echo e($design->cat->name('en')); ?> </td>

                  <td> <?php echo e($design->name('en')); ?> </td>

                  

                  <td>
                    <?php if($design->slider == 'used'): ?>
                      <span class="badge badge-primary">Used</span>
                    <?php else: ?>
                      <span class="badge badge-warning">Un used</span>
                    <?php endif; ?>
                  </td>



                  <td> <img src="<?php echo e(asset("uploads/$design->main_img")); ?> " alt="" style="height:30px;"></td>

                  <td> <?php echo e($design->price); ?> </td>

                  <td>
                    <?php if($design->active == 1): ?>
                      <span class="badge badge-success">Active</span>
                    <?php else: ?>
                      <span class="badge badge-danger">Dactive</span>
                    <?php endif; ?>
                  </td>


                  <td>
                    <a class="btn btn-sm btn-info" href=" <?php echo e(url("/dashboard/designs/show/{$design->id}")); ?> " title="Show Design">
                      <i class="fas fa-eye"></i>
                    </a>

                    <a class="btn btn-sm btn-warning" href=" <?php echo e(url("/dashboard/designs/edit/{$design->id}")); ?> " title="Edit Design">
                      <i class="fas fa-edit"></i>
                    </a>

                    <a class="btn btn-sm btn-danger" href=" <?php echo e(url("/dashboard/designs/delete/{$design->id}")); ?> " title="Delete Design" onclick="return confirm('Are you sure?')">
                      <i class="fas fa-trash"></i>
                    </a>

                    <a class="btn btn-sm btn-secondary" href=" <?php echo e(url("/dashboard/designs/toggle/{$design->id}")); ?> " title="Open or Colsed Status">
                      <i class="fas fa-toggle-on"></i>
                    </a>

                    <a class="btn btn-sm btn-info" href=" <?php echo e(url("/dashboard/designs/slider/{$design->id}")); ?> " title="Make this Design Slider">
                        <i class="fas fa-sliders-h"></i>
                    </a>

                  </td>


                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>

          <div class="d-flex justify-content-center py-2 my-2">
            <?php echo e($designs->links()); ?>

          </div>
        </div>
      </div>


    </div>

  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/admin/designs/index.blade.php ENDPATH**/ ?>