


<?php $__env->startSection('head'); ?>
  Messages
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



  <div class="col py-2">

    <div class="row">
      <div class="col">
        <?php if(session('msgSend')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('msgSend')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="row">
      <div class="col">

        <div class="card">
          <div class="card-header">
            <h3 class="card-title"> All Messages </h3>
          </div>
        </div>

        <?php if($messages->isEmpty()): ?>
        <div>
            <p>No Messages Found</p>
        </div>
        <?php else: ?>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover text-nowrap">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name </th>
                <th>Email</th>
                <th>Subject</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td> <?php echo e($loop->iteration); ?> </td>
                  <td> <?php echo e($msg->user->name); ?> </td>
                  <td> <?php echo e($msg->email); ?> </td>
                  <td> <?php echo e($msg->subject ?? '...'); ?> </td>


                  <td>
                    <a class="btn btn-sm btn-info" href=" <?php echo e(url("/dashboard/messages/show/$msg->id")); ?> " title="Show Message">
                      <i class="fas fa-eye"></i>
                    </a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>

          <div class="d-flex justify-content-center py-2 my-2">
            <?php echo e($messages->links()); ?>

          </div>
        </div>
        <?php endif; ?>
      </div>


    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>