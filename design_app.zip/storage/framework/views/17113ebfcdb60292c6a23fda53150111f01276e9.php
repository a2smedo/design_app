
<?php $__env->startSection('title'); ?>
  Show Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
  Order Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('li'); ?>
  <a href="<?php echo e(url('/dashboard/orders/show/' . $order->id)); ?>">Order</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="col py-2">

    

    <div class="row">
      <div class="col">

        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Order Information </h3>
          </div>
          <div class="card-body">

            <div class="row">
              <div class="col-md-6">
                <p>User Name : <?php echo e($order->user->name); ?> </p>
                <p>Email : <?php echo e($order->user->email); ?> </p>

                <p>Date : <?php echo e(Carbon\Carbon::parse($order->created_at)->format('d M Y - h:i:s A ')); ?> </p>

                <p>Design Name: <?php echo e($order->design_name); ?></p>

                <p>Design Number: <?php echo e($order->design->id); ?></p>

                <p>Design Like : <?php echo e($order->design->name('en')); ?> || <?php echo e($order->design->name('ar')); ?> </p>

                <p>Order Type : <?php echo e($order->design_type); ?></p>
                <p>Order Lang : <?php echo e($order->lang); ?></p>

                <p>Design Color : <?php echo e($order->design->color('en')); ?> || <?php echo e($order->design->color('ar')); ?> </p>

                <p>Design Color : <?php echo e($order->design->font('en')); ?> || <?php echo e($order->design->font('ar')); ?> </p>

              </div>

              <div class="col">

                <p>
                <p>Background:</p>
                <img style="height: 100px" src="<?php echo e(asset("uploads/{$order->design->background}")); ?>" alt="">
                </p>



                <p>Order Details : <?php echo e($order->details); ?> </p>

                <p>Order Status :
                  <?php if($order->status == 'pending'): ?>
                    <span class="badge badge-warning"> <?php echo e($order->status); ?></span>

                  <?php elseif($order->status == 'accepted'): ?>
                    <span class="badge badge-secondary"> <?php echo e($order->status); ?></span>

                  <?php elseif($order->status == 'completed'): ?>
                    <span class="badge badge-success"> <?php echo e($order->status); ?></span>

                  <?php else: ?>
                    <span class="badge badge-danger"> <?php echo e($order->status); ?></span>

                  <?php endif; ?>
                </p>

                <p>Price : <?php echo e($order->design->price); ?> EGP</p>
                <p>Discount : <?php echo e($order->design->discount); ?> %</p>

                <p>
                  <?php

                    $price = $order->design->price;
                    $discount = ($price * $order->design->discount) / 100;

                    $total = $price - $discount;
                  ?>

                  Total : <?php echo e($total); ?> EGP
                </p>

                <p>
                  <a href="<?php echo e(url("/dashboard/orders/accepted/{$order->id}")); ?>" class="btn btn-sm btn-primary">
                    Accepted </a>
                  <a href="<?php echo e(url("/dashboard/orders/completed/{$order->id}")); ?>" class="btn btn-sm btn-success">
                    Completed </a>

                  <a href="<?php echo e(url("/dashboard/orders/canceled/{$order->id}")); ?>" class="btn btn-sm btn-danger"
                    id="cancel">
                    Cancel
                    <i class="fas fa-times"></i>
                  </a>

                </p>
              </div>
            </div>



          </div>
        </div>






        


      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/Admin/orders/show.blade.php ENDPATH**/ ?>