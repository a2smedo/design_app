<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>

  </ul>

  <ul class="navbar-nav ml-auto">
    <li class="nav-item dropdown">
      <a class="nav-link" data-toggle="dropdown" id="notification" href="javascript:;" aria-expanded="fals"
        title="Notifications">
        <i class="far fa-bell"></i>
        <span class="badge badge-warning navbar-badge " id="noti"><?php echo e($notifications_count); ?>

        </span>
      </a>

      <div class="dropdown-menu dropdown-menu-lg dropdown-menu-left div-noti " style="left: inherit; right: 0px; width: 300px;">
        <span class="dropdown-item dropdown-header noti">

          <?php echo e($notifications_count); ?>


          <?php if($notifications_count > 1): ?>
            Notifications
          <?php else: ?>
            Notification
          <?php endif; ?>

        </span>


        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="dropdown-divider"></div>

            <?php if($noti->type == 'order'): ?>
              <a href="<?php echo e(url('/dashboard/orders')); ?>" class="dropdown-item n-link">
                <i class="fas fa-envelope mr-2"></i>

                <span class="text-muted">
                  <?php echo e($noti->where('type', 'order')->count()); ?>


                </span>
                <span class="ml-1 text-muted"> <?php echo e($noti->message); ?> </span>
                <span class="float-right text-muted text-sm"><?php echo e($currentMin); ?> mins</span>
              </a>

            <?php else: ?>
              <a href="<?php echo e(url('/dashboard/users')); ?>" class="dropdown-item n-link">
                <i class="fas fa-envelope mr-2"></i>

                <span class="text-muted">

                  <?php echo e($noti->where('type', 'user')->count()); ?>

                </span>
                <span class="ml-1 text-muted"> <?php echo e($noti->message); ?> </span>
                <span class="float-right text-muted text-sm"><?php echo e($currentMin); ?> mins</span>
              </a>
            <?php endif; ?>

        

          <div class="dropdown-divider"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <a href="<?php echo e(url('/dashboard/notifications')); ?>" class="dropdown-item dropdown-footer">See All
          Notifications</a>

      </div>
    </li>


    <li class="nav-item ">
      <a id="logout" href="<?php echo e(route('logout')); ?>" class="nav-link" title="Logout">
        <i class="nav-icon fas fa-sign-out-alt " style="font-size: 23px !important"></i>
      </a>

      <form id="logout_form" action=" <?php echo e(route('logout')); ?> " method="post" style="display: none;">
        <?php echo csrf_field(); ?>
      </form>
    </li>
  </ul>

</nav>
<?php /**PATH C:\xampp\htdocs\design_app\resources\views/components/navbar.blade.php ENDPATH**/ ?>