


<?php $__env->startSection('head'); ?>
  <?php echo e($competition->name('en') . '||' . $competition->name('ar')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="col">

    <div class="row">
      <div class="col">
        <?php if(session('msgUpdate')): ?>
          <div class="alert alert-info" role="alert">
            <?php echo e(session('msgUpdate')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>

    
    <div class="row">
      <div class="col-md-10 mx-auto">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Design details</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body p-0">
            <table class="table table-sm">

              <tbody>


                <tr>
                  <th>Competition Name</th>
                  <td>
                    <?php echo e($competition->name('en')); ?>

                  </td>
                </tr>
                <tr>
                  <th>Name (en)</th>
                  <td>
                    <?php echo e($competitionDesign->name('en')); ?>

                  </td>
                </tr>
                <tr>
                  <th>Name (ar)</th>
                  <td>
                    <?php echo e($competitionDesign->name('ar')); ?>

                  </td>
                </tr>



                <tr>
                  <th>Main Image</th>
                  <td>
                    <img src="<?php echo e(asset("uploads/designs/design.jpg")); ?>" alt="" style="height: 50px">
                  </td>
                </tr>
                <tr>
                  <th>Description (en)</th>
                  <td>
                    <?php echo e($competitionDesign->desc('en')); ?>

                  </td>
                </tr>
                <tr>
                  <th>Description (ar)</th>
                  <td>
                    <?php echo e($competitionDesign->desc('ar')); ?>

                  </td>
                </tr>


                <tr>
                  <th>Rate</th>
                  <td>
                    <?php echo e($competitionDesign->rate); ?>

                  </td>
                </tr>

                <tr>
                  <th>Active</th>
                  <td>
                    <?php if($competitionDesign->active): ?>
                      <span class="badge badge-success">Active</span>
                    <?php else: ?>
                      <span class="badge badge-danger">Deactive</span>
                    <?php endif; ?>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
      </div>
    </div>
    <div class="row pb-3">
      <div class="col-md-10 mx-auto text-right">


        <a class="btn  btn-primary" href=" <?php echo e(url()->previous()); ?> ">
          Back
        </a>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/Admin/competitions/competition_designs/show-design.blade.php ENDPATH**/ ?>