<?php $__env->startSection('head'); ?>
  Notification
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



  <div class="col py-2">

    <div class="row">
      <div class="col">
        <?php if(session('msgAdd')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('msgAdd')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgUpdate')): ?>
          <div class="alert alert-info" role="alert">
            <?php echo e(session('msgUpdate')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgDeleted')): ?>
          <div class="alert alert-warning" role="alert">
            <?php echo e(session('msgDeleted')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgNoDeleted')): ?>
          <div class="alert alert-danger" role="alert">
            <?php echo e(session('msgNoDeleted')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>


    <div class="row mt-3">
      <div class="col">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title"> Send Notification </h3>
          </div>
        </div>
        <div class="card-body p-0">

          <form action="<?php echo e(url('/dashboard/notifications/send')); ?>" method="post">
            <?php echo csrf_field(); ?>


            <div class="form-group">
              <div class="form-group">
                <label> Users </label>
                <select class="custom-select form-control" name="users[]" required multiple>
                  <option disabled selected value="">Choose Users </option>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"> <?php echo e($user->name); ?> </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label for="body">Message</label>
              <textarea id="body" class="form-control" name="message" rows="3" required minlength="2" maxlength="5000"
                placeholder="Message"></textarea>
            </div>

            <div class="row pb-3">
              <div class="col">
                <a class="btn btn-primary" href=" <?php echo e(url()->previous()); ?> ">
                  Back
                </a>
              </div>
              <div class="col text-right">
                <button type="submit" class="btn btn-success"> Send </button>
              </div>
            </div>

          </form>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col">
        <?php echo $__env->make('Admin.inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>



  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/Admin/notifications/send.blade.php ENDPATH**/ ?>