
<?php $__env->startSection('title'); ?>
  Notifications
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
  Notifications
<?php $__env->stopSection(); ?>

<?php $__env->startSection('li'); ?>
  <a href="<?php echo e(url('/dashboard/orders')); ?>">Orders</a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

  <div class="col py-2">

    
    <div class="row">
      <div class="col">

        <div class="card">
          <div class="card-header">
            <h3 class="card-title"> All Notifications </h3>
          </div>
        </div>



        <div class="card-body table-responsive p-0">
          <table class="table table-hover text-nowrap">
            <thead>
              <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Message</th>
                <th>Type </th>
                <th>Notifications Date </th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notific): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr id="tr">
                  <td> <?php echo e($loop->iteration); ?> </td>

                  <td> <?php echo e($notific->title); ?> </td>
                  <td> <?php echo e($notific->message); ?> </td>
                  <td>
                    <?php if($notific->type == 'order'): ?>
                      <span class="badge badge-success"> <?php echo e($notific->type); ?></span>
                    <?php else: ?>
                      <span class="badge badge-warning"> <?php echo e($notific->type); ?></span>
                    <?php endif; ?>

                  </td>
                  <td> <?php echo e($notific->created_at); ?> </td>


                  <td>
                    <a class="btn btn-sm btn-danger" href=" <?php echo e(url("/dashboard/notifications/delete/{$notific->id}")); ?> " title="Delete Notification" onclick="return confirm('Are you sure?')">
                      <i class="fas fa-trash"></i>
                    </a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p> No Notifications found </p>
              <?php endif; ?>
            </tbody>
          </table>

          <div class="d-flex justify-content-center py-2 my-2">
            <?php echo e($notifications->links()); ?>

          </div>
        </div>


      </div>
    </div>


  </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('Script'); ?>

<script>


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/Admin/notifications/index.blade.php ENDPATH**/ ?>