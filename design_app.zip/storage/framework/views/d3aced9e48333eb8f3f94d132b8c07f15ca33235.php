
<?php $__env->startSection('title'); ?>
Orders
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
Orders
<?php $__env->stopSection(); ?>
<?php $__env->startSection('li'); ?>
<a href="<?php echo e(url('/dashboard/orders')); ?>">Orders</a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

  <div class="col py-2">


    <div class="row">
      <div class="col">

        <div class="card">
          <div class="card-header">
            <h3 class="card-title"> All Orders </h3>
          </div>
        </div>



        <div class="card-body table-responsive p-0">
          <table class="table table-hover text-nowrap">
            <thead>
              <tr>
                <th>ID</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Phone </th>
                <th>Status </th>
                <th>Order Date </th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr id="tr">
                  <td> <?php echo e($loop->iteration); ?> </td>

                  <td> <?php echo e($order->user->name); ?> </td>
                  <td> <?php echo e($order->user->email); ?> </td>
                  <td> <?php echo e($order->user->phone); ?> </td>

                  <td>
                    <?php if($order->status == 'pending'): ?>
                      <span class="badge badge-warning"> <?php echo e($order->status); ?></span>

                    <?php elseif($order->status == 'accepted'): ?>
                      <span class="badge badge-secondary"> <?php echo e($order->status); ?></span>

                    <?php elseif($order->status == 'completed'): ?>
                      <span class="badge badge-success"> <?php echo e($order->status); ?></span>

                    <?php else: ?>
                      <span class="badge badge-danger"> <?php echo e($order->status); ?></span>

                    <?php endif; ?>
                  </td>



                  <td> <?php echo e($order->created_at); ?> </td>



                  <td>
                    <a class="btn btn-sm btn-info" href=" <?php echo e(url("/dashboard/orders/show/{$order->id}")); ?> " title="Show Order">
                      Show
                      <i class="fas fa-eye"></i>
                    </a>

                    <a class="btn btn-sm btn-danger" href=" <?php echo e(url("/dashboard/orders/delete/{$order->id}")); ?> " title="Delete Order" onclick="return confirm('Are you sure?')">
                      <i class="fas fa-trash"></i>
                    </a>

                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <p> No Orders found </p>
            <?php endif; ?>
            </tbody>
          </table>

          <div class="d-flex justify-content-center py-2 my-2">
            <?php echo e($orders->links()); ?>

          </div>
        </div>


      </div>
    </div>


  </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('Script'); ?>

  <script>


  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/Admin/orders/index.blade.php ENDPATH**/ ?>
