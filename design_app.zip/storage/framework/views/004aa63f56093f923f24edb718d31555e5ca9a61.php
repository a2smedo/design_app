


<?php $__env->startSection('head'); ?>
  Create new admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



  <div class="col">

    <div class="row">
      <div class="col">
        <?php echo $__env->make('admin.inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="row">
      <div class="col">

        <form method="POST" action="<?php echo e(url('dashboard/admins/store')); ?>">
          <?php echo csrf_field(); ?>

          <div class="form-group">
            <label for="name"> Name </label>
            <input type="text" class="form-control" name="name">
          </div>

          <div class="form-group">
            <label for="name"> Email </label>
            <input type="email" class="form-control" name="email">
          </div>

          <div class="form-group">
            <label for="name"> Phone </label>
            <input type="text" class="form-control" name="phone">
          </div>

          <div class="form-group">
            <label for="name"> Password </label>
            <input type="password" class="form-control" name="password">
          </div>
          <div class="form-group">
            <label for="name"> Confirm Password </label>
            <input type="password" class="form-control" name="password_confirmation">
          </div>

          <div class="form-group">
            <label> Rule </label>
            <select class="custom-select form-control" name="rule_id">
              <option disabled>Choese Rule </option>
              <?php $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($rule->id); ?>"> <?php echo e($rule->name); ?> </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>


          <div class="row pb-3">

            <div class="col">
              <a class="btn btn-primary" href=" <?php echo e(url()->previous()); ?> ">
                Back
              </a>
            </div>

            <div class="col text-right">
              <button type="submit" class="btn btn-success"> Save </button>
            </div>
          </div>

        </form>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/admin/admins/create.blade.php ENDPATH**/ ?>