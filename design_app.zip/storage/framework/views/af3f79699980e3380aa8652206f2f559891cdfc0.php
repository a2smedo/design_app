


<?php $__env->startSection('head'); ?>
  <?php echo e($design->name('en') . '||' . $design->name('ar')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="col">

    <div class="row">
      <div class="col">
        <?php if(session('msgUpdate')): ?>
          <div class="alert alert-info" role="alert">
            <?php echo e(session('msgUpdate')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>
    <div class="row">
      <div class="col-md-10 mx-auto">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Design details</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body p-0">
            <table class="table table-sm">

              <tbody>


                <tr>
                  <th>Category Name</th>
                  <td>
                    <?php echo e($design->cat->name('en')); ?>

                  </td>
                </tr>
                <tr>
                  <th>Name (en)</th>
                  <td>
                    <?php echo e($design->name('en')); ?>

                  </td>
                </tr>
                <tr>
                  <th>Name (ar)</th>
                  <td>
                    <?php echo e($design->name('ar')); ?>

                  </td>
                </tr>

                <tr>
                  <th>Slider</th>
                  <td>
                    <?php echo e($design->slider); ?>

                  </td>
                </tr>

                <tr>
                  <th>Main Image</th>
                  <td>
                    <img src="<?php echo e(asset("uploads/designs/design.jpg")); ?>" alt="" style="height: 50px">
                  </td>
                </tr>
                <tr>
                  <th>Description (en)</th>
                  <td>
                    <?php echo e($design->desc('en')); ?>

                  </td>
                </tr>
                <tr>
                  <th>Description (ar)</th>
                  <td>
                    <?php echo e($design->desc('ar')); ?>

                  </td>
                </tr>

                <tr>
                  <th>Price</th>
                  <td>
                    <?php echo e($design->price); ?>

                  </td>
                </tr>
                <tr>
                  <th>Discount</th>
                  <td>
                    <?php echo e($design->discount); ?>

                  </td>
                </tr>
                <tr>
                  <th>Language</th>
                  <td>
                    <span> En :   <?php echo e($design->lang("en")); ?> </span>
                    <span>||</span>
                    <span> Ar :   <?php echo e($design->lang("ar")); ?> </span>
                  </td>
                </tr>

                <tr>
                  <th>Background</th>
                  <td>
                    <img src="<?php echo e(asset("uploads/$design->background")); ?>" alt="" height="50px">
                  </td>
                </tr>

                <tr>
                  <th>Font</th>
                  <td>
                    <span>En: <?php echo e($design->font('en')); ?></span>
                    <span>||</span>
                    <span>Ar: <?php echo e($design->font('ar')); ?></span>
                  </td>
                </tr>
                <tr>
                  <th>Color</th>
                  <td>
                   <span>En: <?php echo e($design->color('en')); ?></span>
                   <span>||</span>
                   <span>AR: <?php echo e($design->color('ar')); ?></span>
                  </td>
                </tr>

                <tr>
                  <th>Details(en)</th>
                  <td>
                    <?php echo e($design->details('en')); ?>

                  </td>
                </tr>
                <tr>
                  <th>Details(ar)</th>
                  <td>
                    <?php echo e($design->details('ar')); ?>

                  </td>
                </tr>

                <tr>
                  <th>Rate</th>
                  <td>
                    <?php echo e($design->rate); ?>

                  </td>
                </tr>

                <tr>
                  <th>Active</th>
                  <td>
                    <?php if($design->active): ?>
                      <span class="badge badge-success">Active</span>
                    <?php else: ?>
                      <span class="badge badge-danger">Deactive</span>
                    <?php endif; ?>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
      </div>
    </div>
    <div class="row pb-3">
      <div class="col-md-10 mx-auto text-right">
        <a class="btn  btn-success" href=" <?php echo e(url("/dashboard/designs/show/sub-images/{$design->id}")); ?> ">
          Show Design Images
        </a>

        <a class="btn  btn-primary" href=" <?php echo e(url()->previous()); ?> ">
          Back
        </a>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/Admin/designs/show.blade.php ENDPATH**/ ?>