
<?php $__env->startSection('head'); ?>
  Competitions
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="col py-2">

    <div class="row">
      <div class="col">
        <?php if(session('msgAdd')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('msgAdd')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgUpdate')): ?>
          <div class="alert alert-info" role="alert">
            <?php echo e(session('msgUpdate')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgDeleted')): ?>
          <div class="alert alert-warning" role="alert">
            <?php echo e(session('msgDeleted')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgNoDeleted')): ?>
          <div class="alert alert-danger" role="alert">
            <?php echo e(session('msgNoDeleted')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>



    <div class="row">
      <div class="col">

        <div class="card">
          <div class="card-header">
            <h3 class="card-title"> All Competitions </h3>

            <div class="card-tools">
              <div class="card-tools">
                <a href="<?php echo e(url('/dashboard/competitions/create')); ?>" class="btn btn-primary btn-sm"
                  title="Add new Competition">Add new</a>
              </div>
            </div>
          </div>
        </div>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover text-nowrap">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name (en) </th>
                <th>Name (ar) </th>
                <th>Started</th>
                <th>Expired </th>
                <th>Active</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <td> <?php echo e($loop->iteration); ?> </td>



                  <td> <?php echo e($comp->name('en')); ?> </td>
                  <td> <?php echo e($comp->name('ar')); ?> </td>

                  <td> <?php echo e($comp->started_at); ?> </td>
                  <td> <?php echo e($comp->expired_at); ?> </td>

                  <td>
                    <?php if($comp->active == 1): ?>
                      <span class="badge badge-success">Active</span>
                    <?php else: ?>
                      <span class="badge badge-danger">Dactive</span>
                    <?php endif; ?>
                  </td>


                  <td>
                    <a class="btn btn-sm btn-info" href=" <?php echo e(url("/dashboard/competitions/show/{$comp->id}")); ?> "
                      title="Show Competition">
                      <i class="fas fa-eye"></i>
                    </a>

                    <a class="btn btn-sm btn-warning" href=" <?php echo e(url("/dashboard/competitions/edit/{$comp->id}")); ?> "
                      title="Edit Competition">
                      <i class="fas fa-edit"></i>
                    </a>

                    <a class="btn btn-sm btn-danger delete" href=" <?php echo e(url("/dashboard/competitions/delete/{$comp->id}")); ?> "
                      title="Delete Competition"  onclick="return confirm('Are you sure?')">
                      <i class="fas fa-trash"></i>
                    </a>

                    <a class="btn btn-sm btn-secondary"
                      href=" <?php echo e(url("/dashboard/competitions/toggle/{$comp->id}")); ?> " title="Open or Closed status">
                      <i class="fas fa-toggle-on"></i>
                    </a>

                  </td>


                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>

          <div class="d-flex justify-content-center py-2 my-2">
            <?php echo e($competitions->links()); ?>

          </div>
        </div>
      </div>
    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/Admin/competitions/index.blade.php ENDPATH**/ ?>