


<?php $__env->startSection('head'); ?>
  <?php echo e($competition->name('en') . '||' . $competition->name('ar')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="col">

    <div class="row">
      <div class="col">
        <?php if(session('msgUpdate')): ?>
          <div class="alert alert-info" role="alert">
            <?php echo e(session('msgUpdate')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>
    <div class="row">
      <div class="col-md-10 mx-auto">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Competition details</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body p-0">
            <table class="table table-sm">

              <tbody>

                <tr>
                  <th>Name (en)</th>
                  <td>
                    <?php echo e($competition->name('en')); ?>

                  </td>
                </tr>
                <tr>
                  <th>Name (ar)</th>
                  <td>
                    <?php echo e($competition->name('ar')); ?>

                  </td>
                </tr>


                <tr>
                  <th>Description (en)</th>
                  <td>
                    <?php echo e($competition->desc('en')); ?>

                  </td>
                </tr>
                <tr>
                  <th>Description (ar)</th>
                  <td>
                    <?php echo e($competition->desc('ar')); ?>

                  </td>
                </tr>

                <tr>
                  <th>Started at</th>
                  <td>
                    <?php echo e($competition->started_at); ?>

                  </td>
                </tr>
                <tr>
                  <th>Expired at</th>
                  <td>
                    <?php echo e($competition->expired_at); ?>

                  </td>
                </tr>



                <tr>
                  <th>Active</th>
                  <td>
                    <?php if($competition->active): ?>
                      <span class="badge badge-success">Active</span>
                    <?php else: ?>
                      <span class="badge badge-danger">Deactive</span>
                    <?php endif; ?>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
      </div>
    </div>
    <div class="row pb-3">
      <div class="col-md-10 mx-auto text-right">
        <a class="btn  btn-success" href=" <?php echo e(url("/dashboard/competitions/designs/{$competition->id}")); ?> ">
          Show Competition Designs
        </a>

        <a class="btn  btn-primary" href=" <?php echo e(url()->previous()); ?> ">
          Back
        </a>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/Admin/competitions/show.blade.php ENDPATH**/ ?>