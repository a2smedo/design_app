


<?php $__env->startSection('head'); ?>
  Admins
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



  <div class="col py-2">

    <div class="row">
      <div class="col">
        <?php if(session('msgAdd')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('msgAdd')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgUpdate')): ?>
          <div class="alert alert-info" role="alert">
            <?php echo e(session('msgUpdate')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgDeleted')): ?>
          <div class="alert alert-warning" role="alert">
            <?php echo e(session('msgDeleted')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgNoDeleted')): ?>
          <div class="alert alert-danger" role="alert">
            <?php echo e(session('msgNoDeleted')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="row">
      <div class="col">

        <div class="card">
          <div class="card-header">
            <h3 class="card-title"> All Admins </h3>

            <div class="card-tools">
              <a class="btn btn-sm btn-primary" href=" <?php echo e(url('/dashboard/admins/create')); ?> " title="Add new Admin">Add Admin</a>
            </div>
          </div>
        </div>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover text-nowrap">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name </th>
                <th>Email</th>
                <th>Rule</th>
                <th>Verified</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <td> <?php echo e($loop->iteration); ?> </td>
                  <td> <?php echo e($admin->name); ?> </td>
                  <td> <?php echo e($admin->email); ?> </td>
                  <td> <?php echo e($admin->rule->name); ?> </td>


                  <td>
                    <?php if($admin->status): ?>
                      <span class="badge badge-success">Verified</span>
                    <?php else: ?>
                      <span class="badge badge-danger">Not Verified</span>
                    <?php endif; ?>
                  </td>

                  <td>

                    <?php if($admin->email == 'super_admin@design-app.com'): ?>
                      <div></div>
                    <?php else: ?>

                      <?php if($admin->rule->name == 'admin'): ?>

                        <a class="btn btn-sm btn-success" href=" <?php echo e(url("/dashboard/admins/promot/$admin->id")); ?> " title="Upgrade this Admin">
                          <i class="fas fa-level-up-alt"></i>
                        </a>
                      <?php else: ?>
                        <a class="btn btn-sm btn-danger" href=" <?php echo e(url("/dashboard/admins/demot/$admin->id")); ?> " title="Degrade this Admin">
                          <i class="fas fa-level-down-alt"></i>
                        </a>
                      <?php endif; ?>

                      <a class="btn btn-sm btn-danger" href=" <?php echo e(url("/dashboard/admins/delete/{$admin->id}")); ?> " title="Delete Admin" onclick="return confirm('Are you sure?')">
                        <i class="fas fa-trash"></i>
                      </a>

                    <?php endif; ?>



                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>

          <div class="d-flex justify-content-center py-2 my-2">
            <?php echo e($admins->links()); ?>

          </div>
        </div>
      </div>


    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/admin/admins/index.blade.php ENDPATH**/ ?>