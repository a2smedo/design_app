

<?php $__env->startSection('Css'); ?>

  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
  <?php echo e($competition->name('en')); ?>_Designs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="col py-2">

    <div class="row">
      <div class="col">
        <?php if(session('msgAdd')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('msgAdd')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgUpdate')): ?>
          <div class="alert alert-info" role="alert">
            <?php echo e(session('msgUpdate')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgDeleted')): ?>
          <div class="alert alert-warning" role="alert">
            <?php echo e(session('msgDeleted')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgNoDeleted')): ?>
          <div class="alert alert-danger" role="alert">
            <?php echo e(session('msgNoDeleted')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="row">
      <div class="col">

        <div class="card">
          <div class="card-header">
            <h3 class="card-title"> Competition Designs </h3>

            <div class="card-tools">
              <a href="<?php echo e(url("/dashboard/competitions/create/designs/$competition->id")); ?>" class="btn btn-primary btn-sm">Add new</a>
            </div>
          </div>
        </div>

        <?php if( $competition_designs->isEmpty() ): ?>
            <div></div>

        <?php else: ?>
          <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name (en) </th>
                  <th>Name (ar) </th>
                  <th>Image</th>
                  <th>Rate</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $competition_designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp_d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <td> <?php echo e($loop->iteration); ?> </td>
                    <td> <?php echo e($comp_d->name('en')); ?> </td>
                    <td> <?php echo e($comp_d->name('ar')); ?> </td>

                    <td> <img src="<?php echo e(asset("uploads/$comp_d->img")); ?> " alt="" style="height:30px;"></td>

                    <td> <?php echo e($comp_d->rate); ?> </td>
                    <td>
                      <?php if($comp_d->active == 1): ?>
                        <span class="badge badge-success">Active</span>
                      <?php else: ?>
                        <span class="badge badge-danger">Dactive</span>
                      <?php endif; ?>
                    </td>




                    <td>
                      <a class="btn btn-sm btn-info"
                        href=" <?php echo e(url("/dashboard/competitions/show/designs/{$competition->id}/{$comp_d->id}")); ?> ">
                        <i class="fas fa-eye"></i>
                      </a>

                       <a class="btn btn-sm btn-warning" href=" <?php echo e(url("/dashboard/competitions/edit/designs/{$competition->id}/{$comp_d->id}")); ?> ">
                          <i class="fas fa-edit"></i>
                        </a>
                        <a class="btn btn-sm btn-danger" href=" <?php echo e(url("/dashboard/competitions/delete/designs/{$comp_d->id}")); ?> ">
                            <i class="fas fa-trash"></i>
                        </a>

                        <a class="btn btn-sm btn-secondary" href=" <?php echo e(url("/dashboard/competitions/toggle/designs/{$comp_d->id}")); ?> ">
                            <i class="fas fa-toggle-on"></i>
                        </a>

                    </td>


                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>

            <div class="d-flex justify-content-center py-2 my-2">
              <?php echo e($competition_designs->links()); ?>

            </div>
          </div>
        <?php endif; ?>

      </div>


    </div>

  </div>

























<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/Admin/competitions/competition_designs/all-designs.blade.php ENDPATH**/ ?>