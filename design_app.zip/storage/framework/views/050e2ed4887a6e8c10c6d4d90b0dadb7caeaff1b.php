


<?php $__env->startSection('head'); ?>
  Packages
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="col py-2">

    <div class="row">
      <div class="col">
        <?php if(session('msgAdd')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('msgAdd')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgUpdate')): ?>
          <div class="alert alert-info" role="alert">
            <?php echo e(session('msgUpdate')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgDeleted')): ?>
          <div class="alert alert-warning" role="alert">
            <?php echo e(session('msgDeleted')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('msgNoDeleted')): ?>
          <div class="alert alert-danger" role="alert">
            <?php echo e(session('msgNoDeleted')); ?>

          </div>
        <?php endif; ?>
      </div>
    </div>



    <div class="row">
      <div class="col">

        <div class="card">
          <div class="card-header">
            <h3 class="card-title"> All Packages </h3>

            <div class="card-tools">
              <div class="card-tools">
                <a href="<?php echo e(url('/dashboard/packages/create')); ?>" class="btn btn-primary btn-sm">Add new</a>
              </div>
            </div>
          </div>
        </div>
        <div class="card-body table-responsive p-0">
          <table class="table table-hover text-nowrap">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name (en) </th>
                <th>Name (ar) </th>
                <th>Price</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <td> <?php echo e($loop->iteration); ?> </td>



                  <td> <?php echo e($package->name('en')); ?> </td>
                  <td> <?php echo e($package->name('ar')); ?> </td>


                  <td> <?php echo e($package->price); ?> </td>


                  <td>
                    <a class="btn btn-sm btn-info" href=" <?php echo e(url("/dashboard/packages/show/{$package->id}")); ?> ">
                      <i class="fas fa-eye"></i>
                    </a>

                    <a class="btn btn-sm btn-warning" href=" <?php echo e(url("/dashboard/packages/edit/{$package->id}")); ?> ">
                      <i class="fas fa-edit"></i>
                    </a>

                    <a class="btn btn-sm btn-danger" href=" <?php echo e(url("/dashboard/packages/delete/{$package->id}")); ?> ">
                      <i class="fas fa-trash"></i>
                    </a>

                  </td>


                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>

          <div class="d-flex justify-content-center py-2 my-2">
            <?php echo e($packages->links()); ?>

          </div>
        </div>
      </div>


    </div>

  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\design_app\resources\views/Admin/packages/index.blade.php ENDPATH**/ ?>